<?php
defined('BASEPATH') or exit('No direct script access allowed');

class kuesioner_m extends CI_Model
{

    private $_table = "kuesioner";

    public $id;
    public $pernyataan;
    public function rules()
    {
        return [
            [
                'field' => 'fpernyataan',
                'label' => 'pernyataan',
                'rules' => 'required'
            ],
        ];
    }
    public function rules_update()
    {
        return [
            [
                'field' => 'fpernyataan',
                'label' => 'pernyataan',
                'rules' => 'required'
            ],
        ];
    }

    public function get_all()
    {
        $this->db->select('*');
        $this->db->from($this->_table);
        $query = $this->db->get();
        return $query->result();
    }
    public function get_by_id($id)
    {
        return $this->db->get_where($this->_table, ["id" => $id])->row();
    }
    public function add()
    {
        $post = $this->input->post();
        $this->pernyataan = $post['fpernyataan'];
        $this->db->insert($this->_table, $this);
    }
    public function Delete($id)
    {
        $this->db->delete($this->_table, ['id'=>$id]);
    }
    public function update($post)
    {
        $post = $this->input->post();
        $this->pernyataan = $post['fpernyataan'];
        $this->db->update($this->_table, $this, array('id' => $post['fid_kuesioner']));


    }
}
