<div class="main-content">
    <div class="page-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-6 offset-3">
                <div class="card ">
                <div class="card-header bg-dark">
                        <h3 class="card-title text-light">Input User</h3>
                        </div>
                    <div class="card-body">
                        <form class="form" method="POST" action="">  
                                <div class="mb-3">
                                    <label class="fnama_user">Nama Lengkap</label>
                                    <input type="text" class="form-control" name="fnama_user" required placeholder="nama_lengkap"/>
                                </div>
                                <div class="mb-3">
                                    <label class="fpangkat">pangkat</label>
                                    <input type="text" class="form-control" name="fpangkat" required placeholder="pangkat"/>
                                </div>
                                <div class="mb-3">
                                    <label class="fjabatan">jabatan</label>
                                    <input type="text" class="form-control" name="fjabatan" required placeholder="jabatan"/>
                                </div>
                                <div class="mb-3">
                                    <label class="fkesatuan">kesatuan</label>
                                    <input type="text" class="form-control" name="fkesatuan" required placeholder="kestuan"/>
                                </div>
                                <div class="mb-3">
                                    <label class="fusername">Username</label>
                                    <input type="text" class="form-control" name="fusername" required placeholder="username"/>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Password</label>
                                    <input type="password" id="pass2" class="form-control" name="fpassword" required placeholder="Password"/>
                                </div>
                                <div class="mb-3">
                                    <label for="fpassword">Level</label>
                                    <select class="form-control <?php echo form_error('frole') ? 'is-invalid' : '' ?>" id="frole" name="frole">
                                        <option hidden value="" selected>Pilih Level</option>
                                        <option value="admin" <?= $this->input->post('frole') == "admin" ? 'selected' : '' ?>>admin</option>
                                        <option value="anggota" <?= $this->input->post('frole') == "anggota" ? 'selected' : '' ?>>anggota</option>
                                        <option value="pimpinan" <?= $this->input->post('frole') == "pimpinan" ? 'selected' : '' ?>>pimpinan</option>
                                    </select>
                                    <div class="invalid-feedback">
                                        <?= form_error('frole') ?>
                                    </div>
                                </div>
                                    <div>
                                        <button type="submit" class="btn btn-success float-end">
                                            Submit</button>
                                        <a href="<?= base_url('user') ?>" class="btn btn-secondary float-left">Batal</a>
                                    </div>
                                </div>
                        </form>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->
    </div>
    </div>
</div>