<div class="main-content">
    <div class="page-content">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-flex align-items-center justify-content-between">
                    <h4 class="mb-0">Datatables</h4>
                    <div class="page-title-right">
                        tes
                    </div>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                    <a href="<?= base_url('user/create') ?>" class="btn btn-primary btn-sm float-end"><i class="dripicons-plus"></i> Tambah Data</a>
                        <h3 class="card-title">
                            <i class="fa fa-arrow-right"></i><b> Table untuk User</b>
                        </h3>
                    </div>
                    <div class="card-body">
                        <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead class='bg-dark'>
                                <tr class='text-light'>
                                    <th style="width: 10px">No</th>
                                    <th>Nama Lengkap</th>
                                    <th>pangkat</th>
                                    <th>jabatan</th>
                                    <th>kesatuan</th>
                                    <th>Username</th>
                                    <th>Level</th>
                                    <th style="width: 10px">Modify</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                $no = 1;
                                foreach ($user as $key) : ?>
                                    <tr>
                                        <td><?= $no++ ?></td>
                                        <td><?= $key->nama_lengkap ?></td>
                                        <td><?= $key->pangkat ?></td>
                                        <td><?= $key->jabatan ?></td>
                                        <td><?= $key->kesatuan ?></td>
                                        <td><?= $key->username ?></td>
                                        <td><?= $key->role ?></td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="<?= base_url('user/edit/') . $key->id_user ?>"><button type="button" class="btn btn-default btn-sm" data-toggle="modal" data-target="#modal-detail" data-tolltip="tooltip" data-placement="top"><i class="text-navy fas fa-pencil-alt" data-tolltip="tooltip" data-placement="top" title="Edit"></i></button></a>

                                                <button type="button" class="btn btn-default btn-sm" onclick="deleteConfirm('<?= base_url() . 'user/delete/' . $key->id_user ?>')" data-tolltip="tooltip" data-placement="top" title="Delete"><i class="text-danger fas fa-trash-alt"></i></button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->
    </div>
</div>


<!-- <script>
    $(document).ready(function() {
        $('#TabelUser').DataTable();
        $('[data-tolltip="tooltip"]').tooltip({
            trigger: "hover"
        })

    });
</script> -->

<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <div class="row">
                    <div class="col-3 d-flex justify-content-center">
                        <i class="fa  fa-exclamation-triangle" style="font-size: 70px; color:red;"></i>
                    </div>
                    <div class="col-9 pt-2">
                        <h5>Apakah anda yakin?</h5>
                        <span>Data yang dihapus tidak akan bisa dikembalikan.</span>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <a href="<?= base_url('user') ?>" class="btn btn-secondary btn-md float-left">Batal</a>
                <a id="btn-delete" class="btn btn-danger" href="#"> Hapus</a>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirm -->
<script type="text/javascript">
    function deleteConfirm(url) {
        // console.log('tes');;
        $('#btn-delete').attr('href', url);
        $('#deleteModal').modal('show');
    }
</script>