<div class="main-content">
    <div class="page-content">
    <div class="container-fluid">
        <div class="row">
        <div class="col-6 offset-3">
            <div class="card">
                <div class="card-header bg-dark">
                    <h3 class="card-title text-light">Input data user</h3>
                </div>
                <form role="form" method="POST" action="" autocomplete="off">
                    <input type="hidden" name="fid_user" style="display: none" value="<?= $user->id_user ?>">
                    <input type="hidden" name="fpassword" style="display: none" value="<?= $user->password ?>">

                    <div class="card-body">
                        <div class="form-group">
                            <label for="fnama_user">Nama Lengkap</label>
                            <input type="text" class="form-control <?= form_error('fnama_user') ? 'is-invalid' : '' ?>" id="fnama_user" name="fnama_user" placeholder="Enter Nama Lengkap" value="<?= $user->nama_lengkap ?>">
                            <div class="invalid-feedback">
                                <?= form_error('fnama_user') ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="fpangkat">pangkat</label>
                            <input type="text" class="form-control <?= form_error('fpangkat') ? 'is-invalid' : '' ?>" id="fpangkat" name="fpangkat" placeholder="Enter pangkat" value="<?= $user->pangkat ?>">
                            <div class="invalid-feedback">
                                <?= form_error('fpangkat') ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="fjabatan">jabatan</label>
                            <input type="text" class="form-control <?= form_error('fjabatan') ? 'is-invalid' : '' ?>" id="fjabatan" name="fjabatan" placeholder="Enter jabatan" value="<?= $user->jabatan ?>">
                            <div class="invalid-feedback">
                                <?= form_error('fjabatan') ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="fkesatuan">kesatuan</label>
                            <input type="text" class="form-control <?= form_error('fkesatuan') ? 'is-invalid' : '' ?>" id="fkesatuan" name="fkesatuan" placeholder="Enter kesatuan" value="<?= $user->kesatuan ?>">
                            <div class="invalid-feedback">
                                <?= form_error('fkesatuan') ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="fusername">Username</label>
                            <input type="text" class="form-control <?= form_error('fusername') ? 'is-invalid' : '' ?>" id="fusername" name="fusername" placeholder="Enter Username" value="<?= $user->username ?>">
                            <div class="invalid-feedback">
                                <?= form_error('fusername') ?>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="frole">Level</label>
                            <select class="form-control <?php echo form_error('frole') ? 'is-invalid' : '' ?>" id="frole" name="frole">
                                <?php $role = $this->input->post('frole') ? $this->input->post('frole') : $user->role  ?>
                                <option hidden value="" selected>Pilih Level</option>
                                <option value="admin" <?= $this->input->post('frole') == "admin" ? 'selected' : '' ?>>admin</option>
                                <option value="anggota" <?= $this->input->post('frole') == "anggota" ? 'selected' : '' ?>>anggota</option>
                                <option value="pimpinan" <?= $this->input->post('frole') == "pimpinan" ? 'selected' : '' ?>>pimpinan</option>
                            </select>
                            <div class="invalid-feedback">
                                <?= form_error('frole') ?>
                            </div>
                        </div>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer">
                        <button type="submit" class="btn btn-warning btn-md float-end">Update</button>
                        <a href="<?= base_url('user') ?>" class="btn btn-secondary btn-md float-left">Batal</a>
                    </div>
                </form>
            </div>
            <!-- /.card -->
        </div>
    </div>
    </div>
</div>