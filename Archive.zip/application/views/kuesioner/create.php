<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-6 offset-3">
                    <div class="card ">
                        <div class="card-header bg-dark">
                            <h3 class="card-title text-light">Input Form Kuesioner</h3>
                        </div>
                        <form class="form" method="POST" action="">  
                        <div class="card-body">
                            <div class="mb-3">
                                <label class="fpernyataan">Pernyataan</label>
                                <textarea name="fpernyataan" class="form-control <?= form_error('fpernyataan') ? 'is-invalid' : '' ?>" id="fpernyataan" required cols="30" rows="10"></textarea>
                                <div class="invalid-feedback">
                                    <?= form_error('fpernyataan') ?>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-warning btn-md float-end">Simpan</button>
                            <a href="<?= base_url('kuesioner') ?>" class="btn btn-secondary btn-md float-left">Batal</a>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>