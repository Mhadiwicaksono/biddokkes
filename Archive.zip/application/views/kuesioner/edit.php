<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-6 offset-3">
                    <div class="card">
                        <div class="card-header bg-dark">
                            <h3 class="card-title text-light">Edit Data Kuesioner</h3>
                        </div>
                        <form role="form" method="POST" action="" autocomplete="off">
                        <div class="card-body">
                            <input type="hidden" name="fid_kuesioner" style="display: none" value="<?= $kuesioner->id ?>">
                            <div class="form-group">
                                <label for="fpernyataan">Pernyataan</label>
                                <textarea name="fpernyataan" id="fpernyataan" cols="30" rows="10" class="form-control <?= form_error('fpernyataan') ? 'is-invalid' : '' ?>"><?= $kuesioner->pernyataan ?></textarea>
                                <div class="invalid-feedback">
                                    <?= form_error('fpernyataan') ?>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-warning btn-md float-end">Update</button>
                            <a href="<?= base_url('kuesioner') ?>" class="btn btn-secondary btn-md float-left">Batal</a>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>