<!doctype html>
<html lang="en">

    
<!-- Mirrored from themesbrand.com/minible/layouts/auth-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 25 Feb 2023 08:32:47 GMT -->
<head>
        
        <meta charset="utf-8" />
        <title>Login | Minible - Admin & Dashboard Template</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="Themesbrand" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- Bootstrap Css -->
        <link href="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />

    </head>

    <body class="authentication-bg">
        <div class="account-pages my-5 pt-sm-5">
            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="col-md-8 col-lg-6 col-xl-5">
                        <div class="card">
                           
                            <div class="card-body p-4"> 
                                <div class="text-center mt-2">
                                    <h5 class="text-primary">Aplikasi Biddokkes</h5>
                                    <p class="text-muted">Sign in to continue to Minible.</p>
                                </div>
                                <div class="p-2 mt-4">
                                    <form action="<?= base_url('auth/process') ?>" method="post" >
        
                                        <div class="mb-3">
                                            <label class="form-label" for="username">Username</label>
                                            <input type="text" class="form-control"  placeholder="Enter username" name="fusername">
                                        </div>
                
                                        <div class="mb-3">
                                            <label class="form-label" for="userpassword">Password</label>
                                            <input type="password" class="form-control"  placeholder="Enter password"  name="fpassword">
                                        </div>
                                        
                                        <div class="mt-3 text-end">
                                            <button class="btn btn-primary w-sm waves-effect waves-light" type="submit">Log In</button>
                                        </div>
                                    </form>
                                </div>
            
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>

        <!-- JAVASCRIPT -->
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/jquery/jquery.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/simplebar/simplebar.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/node-waves/waves.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/waypoints/lib/jquery.waypoints.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/jquery.counterup/jquery.counterup.min.js"></script>

        <!-- App js -->
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/js/app.js"></script>
    </body>

<!-- Mirrored from themesbrand.com/minible/layouts/auth-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 25 Feb 2023 08:32:47 GMT -->
</html>