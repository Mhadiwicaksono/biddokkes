<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Aplikasi</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="Themesbrand" name="author" />
        <link rel="shortcut icon" href="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/images/favicon.ico">
        <link href="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
        
    </head>

    <body data-layout="horizontal" data-topbar="colored">
        <div id="layout-wrapper">
            <header id="page-topbar">
                <div class="navbar-header">
                    <div class="d-flex">
                        <div class="navbar-brand-box">
                            <a href="" class="logo logo-light">
                                <span class="logo-sm">
                                    <img src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/images/logo-sm.png" alt="" height="22">
                                </span>
                                <span class="logo-lg">
                                    <img src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/images/logo-light.png" alt="" height="20">
                                </span>
                            </a>
                        </div>
                        <!-- <form class="app-search d-none d-lg-block">
                            <div class="position-relative">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="uil-search"></span>
                            </div>
                        </form> -->
                    </div>
                    <div class="d-flex">
                        <div class="dropdown d-inline-block">
                            <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown"
                                data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img class="rounded-circle header-profile-user" src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/images/users/avatar-4.jpg"
                                    alt="Header Avatar">
                                <span class="d-none d-xl-inline-block ms-1 fw-medium font-size-15">Marcus</span>
                                <i class="uil-angle-down d-none d-xl-inline-block font-size-15"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a class="dropdown-item" href="<?php echo base_url('auth/logout') ?>"><i class="uil uil-sign-out-alt font-size-18 align-middle me-1 text-muted"></i> <span class="align-middle">Sign out</span></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container-fluid">
                    <div class="topnav">
                        <nav class="navbar navbar-light navbar-expand-lg topnav-menu">
                            <div class="collapse navbar-collapse" id="topnav-menu-content">
                                <ul class="navbar-nav">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo base_url('welcome') ?>">
                                            <i class="uil-home-alt me-2"></i> Dashboard
                                        </a>
                                    </li>
                                    <!-- <li class="nav-item">
                                        <a class="nav-link" href="<?php echo base_url('welcome') ?>">
                                            <i class="uil-home-alt me-2"></i> Isi Kuesioner
                                        </a>
                                    </li> -->
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-uielement" role="button">
                                            <i class="uil-flask me-2"></i>Master Data <div class="arrow-down"></div>
                                        </a>

                                        <div class="dropdown-menu mega-dropdown-menu px-2 dropdown-mega-menu-xl" aria-labelledby="topnav-uielement">
                                            <div class="row">
                                                <div class="col-lg-4">
                                                    <div>
                                                        <a href="ui-alerts.html" class="dropdown-item">Nilai Jasmani</a>
                                                        <a href="ui-buttons.html" class="dropdown-item">Nilai Rohani</a>
                                                        <a href="ui-cards.html" class="dropdown-item">Nilai Psikologi</a>
                                                        <a href="ui-carousel.html" class="dropdown-item">Nilai Akademik</a>
                                                        <a href="ui-dropdowns.html" class="dropdown-item">Nilai Kesehatan</a>
                                                        <a href="ui-grid.html" class="dropdown-item">Nilai Litcatpers</a>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo base_url('kuesioner') ?>">
                                            <i class="uil-home-alt me-2"></i> kesehatan
                                        </a>
                                    </li>
                                    <li class="nav-item ">
                                        <a class="nav-link" href="<?php echo base_url('user') ?>">
                                            <i class="uil uil-user-circle me-2"></i> User
                                        </a>
                                    </li>
    
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </header>
            <div class="content-wrapper">
                <div class="content-header">
                    <div class="container-fluid">
                        <?= $contents ?>
                    </div>
                </div>
            </div>
            <div class="content">
                <div class="container-fluid"></div>
                </div>
                    <footer class="footer">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-sm-6">
                                    <script>document.write(new Date().getFullYear())</script> Biddokkes
                                </div>
                            </div>
                        </div>
                    </footer>
                </div>
            </div>
        </div>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/jquery/jquery.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/simplebar/simplebar.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/node-waves/waves.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/waypoints/lib/jquery.waypoints.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/jquery.counterup/jquery.counterup.min.js"></script>

        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/jszip/jszip.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/pdfmake/build/pdfmake.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/pdfmake/build/vfs_fonts.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>
        
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/js/pages/datatables.init.js"></script>

        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/libs/apexcharts/apexcharts.min.js"></script>

        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/js/pages/dashboard.init.js"></script>

        <script src="<?php echo base_url () ?>/template/themesbrand.com/minible/layouts/assets/js/app.js"></script>
    </body>
</html>
