<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kuesioner extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        // check_not_login();
        $this->load->model('kuesioner_m');
        
    }
    public function index()
    {
        $data['kuesioner'] = $this->kuesioner_m->get_all();
        $this->template->load('shared/index', 'kuesioner/index', $data);
    }
    
    public function create()
    {
        $kuesioner  = $this->kuesioner_m;
        $validation = $this->form_validation;
        $validation->set_rules($kuesioner->rules());
        if ($validation->run() == FALSE) {
            // $data['departemen'] = $this->departemen_m->get_all();
            $this->template->load('shared/index', 'kuesioner/create');
        } else {
            $post = $this->input->post(null, TRUE);
            $kuesioner->Add($post);
            if ($this->db->affected_rows() > 0) {
                $this->session->set_flashdata('success', 'Data user berhasil disimpan!');
                redirect('kuesioner', 'refresh');
            }
        }
    }
    public function edit($id = null)
    {
        if (!isset($id)) redirect('kuesioner');
        $kuesioner = $this->kuesioner_m;
        $validation = $this->form_validation;
        $validation->set_rules($kuesioner->rules_update());
        if ($this->form_validation->run()) {
            $post = $this->input->post(null, TRUE);
            $this->kuesioner_m->update($post);
            if ($this->db->affected_rows() > 0) {
                $this->session->set_flashdata('success', 'kuesioner Berhasil Diupdate!');
                redirect('kuesioner', 'refresh');
            } else {
                $this->session->set_flashdata('warning', 'Data kuesioner Tidak Diupdate!');
                redirect('kuesioner', 'refresh');
            }
        }
        $data['kuesioner'] = $this->kuesioner_m->get_by_id($id);
        // $data['departemen'] = $this->departemen_m->get_all();
        if (!$data['kuesioner']) {
            $this->session->set_flashdata('error', 'Data kuesioner Tidak ditemukan!');
            redirect('kuesioner', 'refresh');
        }
        $this->template->load('shared/index', 'kuesioner/edit', $data);
    }
    public function delete($id)
    {
        $this->kuesioner_m->delete($id);
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('success', 'Data kuesioner Berhsil Dihapus!');
            redirect('kuesioner', 'refresh');
        }
    }
}